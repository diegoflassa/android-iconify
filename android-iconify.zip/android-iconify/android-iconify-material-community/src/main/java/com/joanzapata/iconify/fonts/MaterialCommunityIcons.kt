package com.joanzapata.iconify.fonts

import com.joanzapata.iconify.Icon

enum class MaterialCommunityIcons(private val character: Char) : Icon {
    mdi_access_point('\uf101'), mdi_access_point_network('\uf102'), mdi_account('\uf103'), mdi_account_alert(
        '\uf104'
    ),
    mdi_account_box('\uf105'), mdi_account_box_outline('\uf106'), mdi_account_check('\uf107'), mdi_account_circle(
        '\uf108'
    ),
    mdi_account_convert('\uf109'), mdi_account_key('\uf10a'), mdi_account_location('\uf10b'), mdi_account_minus(
        '\uf10c'
    ),
    mdi_account_multiple('\uf10d'), mdi_account_multiple_outline('\uf10e'), mdi_account_multiple_plus(
        '\uf10f'
    ),
    mdi_account_network('\uf110'), mdi_account_off('\uf111'), mdi_account_outline('\uf112'), mdi_account_plus(
        '\uf113'
    ),
    mdi_account_remove('\uf114'), mdi_account_search('\uf115'), mdi_account_star('\uf116'), mdi_account_star_variant(
        '\uf117'
    ),
    mdi_account_switch('\uf118'), mdi_adjust('\uf119'), mdi_air_conditioner('\uf11a'), mdi_airballoon(
        '\uf11b'
    ),
    mdi_airplane('\uf11c'), mdi_airplane_off('\uf11d'), mdi_airplay('\uf11e'), mdi_alarm('\uf11f'), mdi_alarm_check(
        '\uf120'
    ),
    mdi_alarm_multiple('\uf121'), mdi_alarm_off('\uf122'), mdi_alarm_plus('\uf123'), mdi_album(
        '\uf124'
    ),
    mdi_alert('\uf125'), mdi_alert_box('\uf126'), mdi_alert_circle('\uf127'), mdi_alert_octagon(
        '\uf128'
    ),
    mdi_alert_outline('\uf129'), mdi_alpha('\uf12a'), mdi_alphabetical('\uf12b'), mdi_amazon(
        '\uf12c'
    ),
    mdi_amazon_clouddrive('\uf12d'), mdi_ambulance('\uf12e'), mdi_anchor('\uf12f'), mdi_android(
        '\uf130'
    ),
    mdi_android_debug_bridge('\uf131'), mdi_android_studio('\uf132'), mdi_apple('\uf133'), mdi_apple_finder(
        '\uf134'
    ),
    mdi_apple_ios('\uf135'), mdi_apple_mobileme('\uf136'), mdi_apple_safari('\uf137'), mdi_appnet(
        '\uf138'
    ),
    mdi_apps('\uf139'), mdi_archive('\uf13a'), mdi_arrange_bring_forward('\uf13b'), mdi_arrange_bring_to_front(
        '\uf13c'
    ),
    mdi_arrange_send_backward('\uf13d'), mdi_arrange_send_to_back('\uf13e'), mdi_arrow_all('\uf13f'), mdi_arrow_bottom_drop_circle(
        '\uf140'
    ),
    mdi_arrow_bottom_left('\uf141'), mdi_arrow_bottom_right('\uf142'), mdi_arrow_collapse('\uf143'), mdi_arrow_down(
        '\uf144'
    ),
    mdi_arrow_down_bold('\uf145'), mdi_arrow_down_bold_circle('\uf146'), mdi_arrow_down_bold_circle_outline(
        '\uf147'
    ),
    mdi_arrow_down_bold_hexagon_outline('\uf148'), mdi_arrow_expand('\uf149'), mdi_arrow_left(
        '\uf14a'
    ),
    mdi_arrow_left_bold('\uf14b'), mdi_arrow_left_bold_circle('\uf14c'), mdi_arrow_left_bold_circle_outline(
        '\uf14d'
    ),
    mdi_arrow_left_bold_hexagon_outline('\uf14e'), mdi_arrow_right('\uf14f'), mdi_arrow_right_bold(
        '\uf150'
    ),
    mdi_arrow_right_bold_circle('\uf151'), mdi_arrow_right_bold_circle_outline('\uf152'), mdi_arrow_right_bold_hexagon_outline(
        '\uf153'
    ),
    mdi_arrow_top_left('\uf154'), mdi_arrow_top_right('\uf155'), mdi_arrow_up('\uf156'), mdi_arrow_up_bold(
        '\uf157'
    ),
    mdi_arrow_up_bold_circle('\uf158'), mdi_arrow_up_bold_circle_outline('\uf159'), mdi_arrow_up_bold_hexagon_outline(
        '\uf15a'
    ),
    mdi_assistant('\uf15b'), mdi_at('\uf15c'), mdi_attachment('\uf15d'), mdi_audiobook('\uf15e'), mdi_auto_fix(
        '\uf15f'
    ),
    mdi_auto_upload('\uf160'), mdi_autorenew('\uf161'), mdi_av_timer('\uf162'), mdi_baby('\uf163'), mdi_backburger(
        '\uf164'
    ),
    mdi_backspace('\uf165'), mdi_backup_restore('\uf166'), mdi_bank('\uf167'), mdi_barcode('\uf168'), mdi_barcode_scan(
        '\uf169'
    ),
    mdi_barley('\uf16a'), mdi_barrel('\uf16b'), mdi_basecamp('\uf16c'), mdi_basket('\uf16d'), mdi_basket_fill(
        '\uf16e'
    ),
    mdi_basket_unfill('\uf16f'), mdi_battery('\uf170'), mdi_battery_10('\uf171'), mdi_battery_20(
        '\uf172'
    ),
    mdi_battery_30('\uf173'), mdi_battery_40('\uf174'), mdi_battery_50('\uf175'), mdi_battery_60(
        '\uf176'
    ),
    mdi_battery_70('\uf177'), mdi_battery_80('\uf178'), mdi_battery_90('\uf179'), mdi_battery_alert(
        '\uf17a'
    ),
    mdi_battery_charging('\uf17b'), mdi_battery_charging_100('\uf17c'), mdi_battery_charging_20(
        '\uf17d'
    ),
    mdi_battery_charging_30('\uf17e'), mdi_battery_charging_40('\uf17f'), mdi_battery_charging_60(
        '\uf180'
    ),
    mdi_battery_charging_80('\uf181'), mdi_battery_charging_90('\uf182'), mdi_battery_minus('\uf183'), mdi_battery_negative(
        '\uf184'
    ),
    mdi_battery_outline('\uf185'), mdi_battery_plus('\uf186'), mdi_battery_positive('\uf187'), mdi_battery_unknown(
        '\uf188'
    ),
    mdi_beach('\uf189'), mdi_beaker('\uf18a'), mdi_beaker_empty('\uf18b'), mdi_beaker_empty_outline(
        '\uf18c'
    ),
    mdi_beaker_outline('\uf18d'), mdi_beats('\uf18e'), mdi_beer('\uf18f'), mdi_behance('\uf190'), mdi_bell(
        '\uf191'
    ),
    mdi_bell_off('\uf192'), mdi_bell_outline('\uf193'), mdi_bell_plus('\uf194'), mdi_bell_ring(
        '\uf195'
    ),
    mdi_bell_ring_outline('\uf196'), mdi_bell_sleep('\uf197'), mdi_beta('\uf198'), mdi_bike('\uf199'), mdi_bing(
        '\uf19a'
    ),
    mdi_binoculars('\uf19b'), mdi_bio('\uf19c'), mdi_biohazard('\uf19d'), mdi_bitbucket('\uf19e'), mdi_black_mesa(
        '\uf19f'
    ),
    mdi_blackberry('\uf1a0'), mdi_blender('\uf1a1'), mdi_blinds('\uf1a2'), mdi_block_helper('\uf1a3'), mdi_blogger(
        '\uf1a4'
    ),
    mdi_bluetooth('\uf1a5'), mdi_bluetooth_audio('\uf1a6'), mdi_bluetooth_connect('\uf1a7'), mdi_bluetooth_off(
        '\uf1a8'
    ),
    mdi_bluetooth_settings('\uf1a9'), mdi_bluetooth_transfer('\uf1aa'), mdi_blur('\uf1ab'), mdi_blur_linear(
        '\uf1ac'
    ),
    mdi_blur_off('\uf1ad'), mdi_blur_radial('\uf1ae'), mdi_bone('\uf1af'), mdi_book('\uf1b0'), mdi_book_multiple(
        '\uf1b1'
    ),
    mdi_book_multiple_variant('\uf1b2'), mdi_book_open('\uf1b3'), mdi_book_open_variant('\uf1b4'), mdi_book_variant(
        '\uf1b5'
    ),
    mdi_bookmark('\uf1b6'), mdi_bookmark_check('\uf1b7'), mdi_bookmark_music('\uf1b8'), mdi_bookmark_outline(
        '\uf1b9'
    ),
    mdi_bookmark_outline_plus('\uf1ba'), mdi_bookmark_plus('\uf1bb'), mdi_bookmark_remove('\uf1bc'), mdi_border_all(
        '\uf1bd'
    ),
    mdi_border_bottom('\uf1be'), mdi_border_color('\uf1bf'), mdi_border_horizontal('\uf1c0'), mdi_border_inside(
        '\uf1c1'
    ),
    mdi_border_left('\uf1c2'), mdi_border_none('\uf1c3'), mdi_border_outside('\uf1c4'), mdi_border_right(
        '\uf1c5'
    ),
    mdi_border_style('\uf1c6'), mdi_border_top('\uf1c7'), mdi_border_vertical('\uf1c8'), mdi_bowling(
        '\uf1c9'
    ),
    mdi_box('\uf1ca'), mdi_box_cutter('\uf1cb'), mdi_briefcase('\uf1cc'), mdi_briefcase_check(
        '\uf1cd'
    ),
    mdi_briefcase_download('\uf1ce'), mdi_briefcase_upload('\uf1cf'), mdi_brightness_1('\uf1d0'), mdi_brightness_2(
        '\uf1d1'
    ),
    mdi_brightness_3('\uf1d2'), mdi_brightness_4('\uf1d3'), mdi_brightness_5('\uf1d4'), mdi_brightness_6(
        '\uf1d5'
    ),
    mdi_brightness_7('\uf1d6'), mdi_brightness_auto('\uf1d7'), mdi_broom('\uf1d8'), mdi_brush(
        '\uf1d9'
    ),
    mdi_bug('\uf1da'), mdi_bulletin_board('\uf1db'), mdi_bullhorn('\uf1dc'), mdi_bus('\uf1dd'), mdi_cached(
        '\uf1de'
    ),
    mdi_cake('\uf1df'), mdi_cake_layered('\uf1e0'), mdi_cake_variant('\uf1e1'), mdi_calculator(
        '\uf1e2'
    ),
    mdi_calendar('\uf1e3'), mdi_calendar_blank('\uf1e4'), mdi_calendar_check('\uf1e5'), mdi_calendar_clock(
        '\uf1e6'
    ),
    mdi_calendar_multiple('\uf1e7'), mdi_calendar_multiple_check('\uf1e8'), mdi_calendar_plus(
        '\uf1e9'
    ),
    mdi_calendar_remove('\uf1ea'), mdi_calendar_text('\uf1eb'), mdi_calendar_today('\uf1ec'), mdi_call_made(
        '\uf1ed'
    ),
    mdi_call_merge('\uf1ee'), mdi_call_missed('\uf1ef'), mdi_call_received('\uf1f0'), mdi_call_split(
        '\uf1f1'
    ),
    mdi_camcorder('\uf1f2'), mdi_camcorder_box('\uf1f3'), mdi_camcorder_box_off('\uf1f4'), mdi_camcorder_off(
        '\uf1f5'
    ),
    mdi_camera('\uf1f6'), mdi_camera_enhance('\uf1f7'), mdi_camera_front('\uf1f8'), mdi_camera_front_variant(
        '\uf1f9'
    ),
    mdi_camera_iris('\uf1fa'), mdi_camera_party_mode('\uf1fb'), mdi_camera_rear('\uf1fc'), mdi_camera_rear_variant(
        '\uf1fd'
    ),
    mdi_camera_switch('\uf1fe'), mdi_camera_timer('\uf1ff'), mdi_candycane('\uf200'), mdi_car(
        '\uf201'
    ),
    mdi_car_battery('\uf202'), mdi_car_connected('\uf203'), mdi_car_wash('\uf204'), mdi_carrot(
        '\uf205'
    ),
    mdi_cart('\uf206'), mdi_cart_outline('\uf207'), mdi_cart_plus('\uf208'), mdi_case_sensitive_alt(
        '\uf209'
    ),
    mdi_cash('\uf20a'), mdi_cash_100('\uf20b'), mdi_cash_multiple('\uf20c'), mdi_cash_usd('\uf20d'), mdi_cast(
        '\uf20e'
    ),
    mdi_cast_connected('\uf20f'), mdi_castle('\uf210'), mdi_cat('\uf211'), mdi_cellphone('\uf212'), mdi_cellphone_android(
        '\uf213'
    ),
    mdi_cellphone_basic('\uf214'), mdi_cellphone_dock('\uf215'), mdi_cellphone_iphone('\uf216'), mdi_cellphone_link(
        '\uf217'
    ),
    mdi_cellphone_link_off('\uf218'), mdi_cellphone_settings('\uf219'), mdi_certificate('\uf21a'), mdi_chair_school(
        '\uf21b'
    ),
    mdi_chart_arc('\uf21c'), mdi_chart_areaspline('\uf21d'), mdi_chart_bar('\uf21e'), mdi_chart_histogram(
        '\uf21f'
    ),
    mdi_chart_line('\uf220'), mdi_chart_pie('\uf221'), mdi_check('\uf222'), mdi_check_all('\uf223'), mdi_checkbox_blank(
        '\uf224'
    ),
    mdi_checkbox_blank_circle('\uf225'), mdi_checkbox_blank_circle_outline('\uf226'), mdi_checkbox_blank_outline(
        '\uf227'
    ),
    mdi_checkbox_marked('\uf228'), mdi_checkbox_marked_circle('\uf229'), mdi_checkbox_marked_circle_outline(
        '\uf22a'
    ),
    mdi_checkbox_marked_outline('\uf22b'), mdi_checkbox_multiple_blank('\uf22c'), mdi_checkbox_multiple_blank_outline(
        '\uf22d'
    ),
    mdi_checkbox_multiple_marked('\uf22e'), mdi_checkbox_multiple_marked_outline('\uf22f'), mdi_checkerboard(
        '\uf230'
    ),
    mdi_chemical_weapon('\uf231'), mdi_chevron_double_down('\uf232'), mdi_chevron_double_left(
        '\uf233'
    ),
    mdi_chevron_double_right('\uf234'), mdi_chevron_double_up('\uf235'), mdi_chevron_down('\uf236'), mdi_chevron_left(
        '\uf237'
    ),
    mdi_chevron_right('\uf238'), mdi_chevron_up('\uf239'), mdi_church('\uf23a'), mdi_cisco_webex(
        '\uf23b'
    ),
    mdi_city('\uf23c'), mdi_clipboard('\uf23d'), mdi_clipboard_account('\uf23e'), mdi_clipboard_alert(
        '\uf23f'
    ),
    mdi_clipboard_arrow_down('\uf240'), mdi_clipboard_arrow_left('\uf241'), mdi_clipboard_check(
        '\uf242'
    ),
    mdi_clipboard_outline('\uf243'), mdi_clipboard_text('\uf244'), mdi_clippy('\uf245'), mdi_clock(
        '\uf246'
    ),
    mdi_clock_end('\uf247'), mdi_clock_fast('\uf248'), mdi_clock_in('\uf249'), mdi_clock_out(
        '\uf24a'
    ),
    mdi_clock_start('\uf24b'), mdi_close('\uf24c'), mdi_close_box('\uf24d'), mdi_close_box_outline(
        '\uf24e'
    ),
    mdi_close_circle('\uf24f'), mdi_close_circle_outline('\uf250'), mdi_close_network('\uf251'), mdi_close_octagon(
        '\uf252'
    ),
    mdi_close_octagon_outline('\uf253'), mdi_closed_caption('\uf254'), mdi_cloud('\uf255'), mdi_cloud_check(
        '\uf256'
    ),
    mdi_cloud_circle('\uf257'), mdi_cloud_download('\uf258'), mdi_cloud_outline('\uf259'), mdi_cloud_outline_off(
        '\uf25a'
    ),
    mdi_cloud_print('\uf25b'), mdi_cloud_print_outline('\uf25c'), mdi_cloud_upload('\uf25d'), mdi_code_array(
        '\uf25e'
    ),
    mdi_code_braces('\uf25f'), mdi_code_brackets('\uf260'), mdi_code_equal('\uf261'), mdi_code_greater_than(
        '\uf262'
    ),
    mdi_code_greater_than_or_equal('\uf263'), mdi_code_less_than('\uf264'), mdi_code_less_than_or_equal(
        '\uf265'
    ),
    mdi_code_not_equal('\uf266'), mdi_code_not_equal_variant('\uf267'), mdi_code_parentheses(
        '\uf268'
    ),
    mdi_code_string('\uf269'), mdi_code_tags('\uf26a'), mdi_codepen('\uf26b'), mdi_coffee('\uf26c'), mdi_coffee_to_go(
        '\uf26d'
    ),
    mdi_coin('\uf26e'), mdi_color_helper('\uf26f'), mdi_comment('\uf270'), mdi_comment_account(
        '\uf271'
    ),
    mdi_comment_account_outline('\uf272'), mdi_comment_alert('\uf273'), mdi_comment_alert_outline(
        '\uf274'
    ),
    mdi_comment_check('\uf275'), mdi_comment_check_outline('\uf276'), mdi_comment_multiple_outline(
        '\uf277'
    ),
    mdi_comment_outline('\uf278'), mdi_comment_plus_outline('\uf279'), mdi_comment_processing(
        '\uf27a'
    ),
    mdi_comment_processing_outline('\uf27b'), mdi_comment_question_outline('\uf27c'), mdi_comment_remove_outline(
        '\uf27d'
    ),
    mdi_comment_text('\uf27e'), mdi_comment_text_outline('\uf27f'), mdi_compare('\uf280'), mdi_compass(
        '\uf281'
    ),
    mdi_compass_outline('\uf282'), mdi_console('\uf283'), mdi_contact_mail('\uf284'), mdi_content_copy(
        '\uf285'
    ),
    mdi_content_cut('\uf286'), mdi_content_duplicate('\uf287'), mdi_content_paste('\uf288'), mdi_content_save(
        '\uf289'
    ),
    mdi_content_save_all('\uf28a'), mdi_contrast('\uf28b'), mdi_contrast_box('\uf28c'), mdi_contrast_circle(
        '\uf28d'
    ),
    mdi_cookie('\uf28e'), mdi_cow('\uf28f'), mdi_credit_card('\uf290'), mdi_credit_card_multiple(
        '\uf291'
    ),
    mdi_credit_card_scan('\uf292'), mdi_crop('\uf293'), mdi_crop_free('\uf294'), mdi_crop_landscape(
        '\uf295'
    ),
    mdi_crop_portrait('\uf296'), mdi_crop_square('\uf297'), mdi_crosshairs('\uf298'), mdi_crosshairs_gps(
        '\uf299'
    ),
    mdi_crown('\uf29a'), mdi_cube('\uf29b'), mdi_cube_outline('\uf29c'), mdi_cube_send('\uf29d'), mdi_cube_unfolded(
        '\uf29e'
    ),
    mdi_cup('\uf29f'), mdi_cup_water('\uf2a0'), mdi_currency_btc('\uf2a1'), mdi_currency_eur(
        '\uf2a2'
    ),
    mdi_currency_gbp('\uf2a3'), mdi_currency_inr('\uf2a4'), mdi_currency_ngn('\uf2a5'), mdi_currency_rub(
        '\uf2a6'
    ),
    mdi_currency_try('\uf2a7'), mdi_currency_usd('\uf2a8'), mdi_cursor_default('\uf2a9'), mdi_cursor_default_outline(
        '\uf2aa'
    ),
    mdi_cursor_move('\uf2ab'), mdi_cursor_pointer('\uf2ac'), mdi_database('\uf2ad'), mdi_database_minus(
        '\uf2ae'
    ),
    mdi_database_plus('\uf2af'), mdi_debug_step_into('\uf2b0'), mdi_debug_step_out('\uf2b1'), mdi_debug_step_over(
        '\uf2b2'
    ),
    mdi_decimal_decrease('\uf2b3'), mdi_decimal_increase('\uf2b4'), mdi_delete('\uf2b5'), mdi_delete_variant(
        '\uf2b6'
    ),
    mdi_delta('\uf2b7'), mdi_deskphone('\uf2b8'), mdi_desktop_mac('\uf2b9'), mdi_desktop_tower(
        '\uf2ba'
    ),
    mdi_details('\uf2bb'), mdi_deviantart('\uf2bc'), mdi_diamond('\uf2bd'), mdi_dice('\uf2be'), mdi_dice_1(
        '\uf2bf'
    ),
    mdi_dice_2('\uf2c0'), mdi_dice_3('\uf2c1'), mdi_dice_4('\uf2c2'), mdi_dice_5('\uf2c3'), mdi_dice_6(
        '\uf2c4'
    ),
    mdi_directions('\uf2c5'), mdi_disk_alert('\uf2c6'), mdi_disqus('\uf2c7'), mdi_disqus_outline(
        '\uf2c8'
    ),
    mdi_division('\uf2c9'), mdi_division_box('\uf2ca'), mdi_dns('\uf2cb'), mdi_domain('\uf2cc'), mdi_dots_horizontal(
        '\uf2cd'
    ),
    mdi_dots_vertical('\uf2ce'), mdi_download('\uf2cf'), mdi_drag('\uf2d0'), mdi_drag_horizontal(
        '\uf2d1'
    ),
    mdi_drag_vertical('\uf2d2'), mdi_drawing('\uf2d3'), mdi_drawing_box('\uf2d4'), mdi_dribbble(
        '\uf2d5'
    ),
    mdi_dribbble_box('\uf2d6'), mdi_drone('\uf2d7'), mdi_dropbox('\uf2d8'), mdi_drupal('\uf2d9'), mdi_duck(
        '\uf2da'
    ),
    mdi_dumbbell('\uf2db'), mdi_earth('\uf2dc'), mdi_earth_off('\uf2dd'), mdi_edge('\uf2de'), mdi_eject(
        '\uf2df'
    ),
    mdi_elevation_decline('\uf2e0'), mdi_elevation_rise('\uf2e1'), mdi_elevator('\uf2e2'), mdi_email(
        '\uf2e3'
    ),
    mdi_email_open('\uf2e4'), mdi_email_outline('\uf2e5'), mdi_email_secure('\uf2e6'), mdi_emoticon(
        '\uf2e7'
    ),
    mdi_emoticon_cool('\uf2e8'), mdi_emoticon_devil('\uf2e9'), mdi_emoticon_happy('\uf2ea'), mdi_emoticon_neutral(
        '\uf2eb'
    ),
    mdi_emoticon_poop('\uf2ec'), mdi_emoticon_sad('\uf2ed'), mdi_emoticon_tongue('\uf2ee'), mdi_engine(
        '\uf2ef'
    ),
    mdi_engine_outline('\uf2f0'), mdi_equal('\uf2f1'), mdi_equal_box('\uf2f2'), mdi_eraser('\uf2f3'), mdi_escalator(
        '\uf2f4'
    ),
    mdi_ethernet('\uf2f5'), mdi_ethernet_cable('\uf2f6'), mdi_ethernet_cable_off('\uf2f7'), mdi_etsy(
        '\uf2f8'
    ),
    mdi_evernote('\uf2f9'), mdi_exclamation('\uf2fa'), mdi_exit_to_app('\uf2fb'), mdi_export(
        '\uf2fc'
    ),
    mdi_eye('\uf2fd'), mdi_eye_off('\uf2fe'), mdi_eyedropper('\uf2ff'), mdi_eyedropper_variant(
        '\uf300'
    ),
    mdi_facebook('\uf301'), mdi_facebook_box('\uf302'), mdi_facebook_messenger('\uf303'), mdi_factory(
        '\uf304'
    ),
    mdi_fan('\uf305'), mdi_fast_forward('\uf306'), mdi_fax('\uf307'), mdi_ferry('\uf308'), mdi_file(
        '\uf309'
    ),
    mdi_file_chart('\uf30a'), mdi_file_check('\uf30b'), mdi_file_cloud('\uf30c'), mdi_file_delimited(
        '\uf30d'
    ),
    mdi_file_document('\uf30e'), mdi_file_document_box('\uf30f'), mdi_file_excel('\uf310'), mdi_file_excel_box(
        '\uf311'
    ),
    mdi_file_export('\uf312'), mdi_file_find('\uf313'), mdi_file_image('\uf314'), mdi_file_import(
        '\uf315'
    ),
    mdi_file_lock('\uf316'), mdi_file_multiple('\uf317'), mdi_file_music('\uf318'), mdi_file_outline(
        '\uf319'
    ),
    mdi_file_pdf('\uf31a'), mdi_file_pdf_box('\uf31b'), mdi_file_powerpoint('\uf31c'), mdi_file_powerpoint_box(
        '\uf31d'
    ),
    mdi_file_presentation_box('\uf31e'), mdi_file_send('\uf31f'), mdi_file_video('\uf320'), mdi_file_word(
        '\uf321'
    ),
    mdi_file_word_box('\uf322'), mdi_file_xml('\uf323'), mdi_film('\uf324'), mdi_filmstrip('\uf325'), mdi_filmstrip_off(
        '\uf326'
    ),
    mdi_filter('\uf327'), mdi_filter_outline('\uf328'), mdi_filter_remove('\uf329'), mdi_filter_remove_outline(
        '\uf32a'
    ),
    mdi_filter_variant('\uf32b'), mdi_fingerprint('\uf32c'), mdi_fire('\uf32d'), mdi_firefox(
        '\uf32e'
    ),
    mdi_fish('\uf32f'), mdi_flag('\uf330'), mdi_flag_checkered('\uf331'), mdi_flag_outline('\uf332'), mdi_flag_outline_variant(
        '\uf333'
    ),
    mdi_flag_triangle('\uf334'), mdi_flag_variant('\uf335'), mdi_flash('\uf336'), mdi_flash_auto(
        '\uf337'
    ),
    mdi_flash_off('\uf338'), mdi_flashlight('\uf339'), mdi_flashlight_off('\uf33a'), mdi_flattr(
        '\uf33b'
    ),
    mdi_flip_to_back('\uf33c'), mdi_flip_to_front('\uf33d'), mdi_floppy('\uf33e'), mdi_flower(
        '\uf33f'
    ),
    mdi_folder('\uf340'), mdi_folder_account('\uf341'), mdi_folder_download('\uf342'), mdi_folder_google_drive(
        '\uf343'
    ),
    mdi_folder_image('\uf344'), mdi_folder_lock('\uf345'), mdi_folder_lock_open('\uf346'), mdi_folder_move(
        '\uf347'
    ),
    mdi_folder_multiple('\uf348'), mdi_folder_multiple_image('\uf349'), mdi_folder_multiple_outline(
        '\uf34a'
    ),
    mdi_folder_outline('\uf34b'), mdi_folder_plus('\uf34c'), mdi_folder_remove('\uf34d'), mdi_folder_upload(
        '\uf34e'
    ),
    mdi_food('\uf34f'), mdi_food_apple('\uf350'), mdi_food_variant('\uf351'), mdi_football('\uf352'), mdi_football_australian(
        '\uf353'
    ),
    mdi_football_helmet('\uf354'), mdi_format_align_center('\uf355'), mdi_format_align_justify(
        '\uf356'
    ),
    mdi_format_align_left('\uf357'), mdi_format_align_right('\uf358'), mdi_format_bold('\uf359'), mdi_format_clear(
        '\uf35a'
    ),
    mdi_format_color_fill('\uf35b'), mdi_format_float_center('\uf35c'), mdi_format_float_left(
        '\uf35d'
    ),
    mdi_format_float_none('\uf35e'), mdi_format_float_right('\uf35f'), mdi_format_header_1('\uf360'), mdi_format_header_2(
        '\uf361'
    ),
    mdi_format_header_3('\uf362'), mdi_format_header_4('\uf363'), mdi_format_header_5('\uf364'), mdi_format_header_6(
        '\uf365'
    ),
    mdi_format_header_decrease('\uf366'), mdi_format_header_equal('\uf367'), mdi_format_header_increase(
        '\uf368'
    ),
    mdi_format_header_pound('\uf369'), mdi_format_indent_decrease('\uf36a'), mdi_format_indent_increase(
        '\uf36b'
    ),
    mdi_format_italic('\uf36c'), mdi_format_line_spacing('\uf36d'), mdi_format_list_bulleted(
        '\uf36e'
    ),
    mdi_format_list_bulleted_type('\uf36f'), mdi_format_list_numbers('\uf370'), mdi_format_paint(
        '\uf371'
    ),
    mdi_format_paragraph('\uf372'), mdi_format_quote('\uf373'), mdi_format_size('\uf374'), mdi_format_strikethrough(
        '\uf375'
    ),
    mdi_format_strikethrough_variant('\uf376'), mdi_format_subscript('\uf377'), mdi_format_superscript(
        '\uf378'
    ),
    mdi_format_text('\uf379'), mdi_format_textdirection_l_to_r('\uf37a'), mdi_format_textdirection_r_to_l(
        '\uf37b'
    ),
    mdi_format_underline('\uf37c'), mdi_format_wrap_inline('\uf37d'), mdi_format_wrap_square(
        '\uf37e'
    ),
    mdi_format_wrap_tight('\uf37f'), mdi_format_wrap_top_bottom('\uf380'), mdi_forum('\uf381'), mdi_forward(
        '\uf382'
    ),
    mdi_foursquare('\uf383'), mdi_fridge('\uf384'), mdi_fridge_filled('\uf385'), mdi_fridge_filled_bottom(
        '\uf386'
    ),
    mdi_fridge_filled_top('\uf387'), mdi_fullscreen('\uf388'), mdi_fullscreen_exit('\uf389'), mdi_function(
        '\uf38a'
    ),
    mdi_gamepad('\uf38b'), mdi_gamepad_variant('\uf38c'), mdi_gas_station('\uf38d'), mdi_gate(
        '\uf38e'
    ),
    mdi_gauge('\uf38f'), mdi_gavel('\uf390'), mdi_gender_female('\uf391'), mdi_gender_male('\uf392'), mdi_gender_male_female(
        '\uf393'
    ),
    mdi_gender_transgender('\uf394'), mdi_ghost('\uf395'), mdi_gift('\uf396'), mdi_git('\uf397'), mdi_github_box(
        '\uf398'
    ),
    mdi_github_circle('\uf399'), mdi_glass_flute('\uf39a'), mdi_glass_mug('\uf39b'), mdi_glass_stange(
        '\uf39c'
    ),
    mdi_glass_tulip('\uf39d'), mdi_glasses('\uf39e'), mdi_gmail('\uf39f'), mdi_google('\uf3a0'), mdi_google_cardboard(
        '\uf3a1'
    ),
    mdi_google_chrome('\uf3a2'), mdi_google_circles('\uf3a3'), mdi_google_circles_communities(
        '\uf3a4'
    ),
    mdi_google_circles_extended('\uf3a5'), mdi_google_circles_group('\uf3a6'), mdi_google_controller(
        '\uf3a7'
    ),
    mdi_google_controller_off('\uf3a8'), mdi_google_drive('\uf3a9'), mdi_google_earth('\uf3aa'), mdi_google_glass(
        '\uf3ab'
    ),
    mdi_google_nearby('\uf3ac'), mdi_google_pages('\uf3ad'), mdi_google_physical_web('\uf3ae'), mdi_google_play(
        '\uf3af'
    ),
    mdi_google_plus('\uf3b0'), mdi_google_plus_box('\uf3b1'), mdi_google_translate('\uf3b2'), mdi_google_wallet(
        '\uf3b3'
    ),
    mdi_grid('\uf3b4'), mdi_grid_off('\uf3b5'), mdi_group('\uf3b6'), mdi_guitar('\uf3b7'), mdi_guitar_pick(
        '\uf3b8'
    ),
    mdi_guitar_pick_outline('\uf3b9'), mdi_hand_pointing_right('\uf3ba'), mdi_hanger('\uf3bb'), mdi_hangouts(
        '\uf3bc'
    ),
    mdi_harddisk('\uf3bd'), mdi_headphones('\uf3be'), mdi_headphones_box('\uf3bf'), mdi_headphones_settings(
        '\uf3c0'
    ),
    mdi_headset('\uf3c1'), mdi_headset_dock('\uf3c2'), mdi_headset_off('\uf3c3'), mdi_heart('\uf3c4'), mdi_heart_box(
        '\uf3c5'
    ),
    mdi_heart_box_outline('\uf3c6'), mdi_heart_broken('\uf3c7'), mdi_heart_outline('\uf3c8'), mdi_help(
        '\uf3c9'
    ),
    mdi_help_circle('\uf3ca'), mdi_hexagon('\uf3cb'), mdi_hexagon_outline('\uf3cc'), mdi_history(
        '\uf3cd'
    ),
    mdi_hololens('\uf3ce'), mdi_home('\uf3cf'), mdi_home_modern('\uf3d0'), mdi_home_variant('\uf3d1'), mdi_hops(
        '\uf3d2'
    ),
    mdi_hospital('\uf3d3'), mdi_hospital_building('\uf3d4'), mdi_hospital_marker('\uf3d5'), mdi_hotel(
        '\uf3d6'
    ),
    mdi_houzz('\uf3d7'), mdi_houzz_box('\uf3d8'), mdi_human('\uf3d9'), mdi_human_child('\uf3da'), mdi_human_male_female(
        '\uf3db'
    ),
    mdi_image('\uf3dc'), mdi_image_album('\uf3dd'), mdi_image_area('\uf3de'), mdi_image_area_close(
        '\uf3df'
    ),
    mdi_image_broken('\uf3e0'), mdi_image_broken_variant('\uf3e1'), mdi_image_filter('\uf3e2'), mdi_image_filter_black_white(
        '\uf3e3'
    ),
    mdi_image_filter_center_focus('\uf3e4'), mdi_image_filter_center_focus_weak('\uf3e5'), mdi_image_filter_drama(
        '\uf3e6'
    ),
    mdi_image_filter_frames('\uf3e7'), mdi_image_filter_hdr('\uf3e8'), mdi_image_filter_none(
        '\uf3e9'
    ),
    mdi_image_filter_tilt_shift('\uf3ea'), mdi_image_filter_vintage('\uf3eb'), mdi_image_multiple(
        '\uf3ec'
    ),
    mdi_import('\uf3ed'), mdi_inbox('\uf3ee'), mdi_information('\uf3ef'), mdi_information_outline(
        '\uf3f0'
    ),
    mdi_instagram('\uf3f1'), mdi_instapaper('\uf3f2'), mdi_internet_explorer('\uf3f3'), mdi_invert_colors(
        '\uf3f4'
    ),
    mdi_jeepney('\uf3f5'), mdi_jira('\uf3f6'), mdi_jsfiddle('\uf3f7'), mdi_keg('\uf3f8'), mdi_key(
        '\uf3f9'
    ),
    mdi_key_change('\uf3fa'), mdi_key_minus('\uf3fb'), mdi_key_plus('\uf3fc'), mdi_key_remove(
        '\uf3fd'
    ),
    mdi_key_variant('\uf3fe'), mdi_keyboard('\uf3ff'), mdi_keyboard_backspace('\uf400'), mdi_keyboard_caps(
        '\uf401'
    ),
    mdi_keyboard_close('\uf402'), mdi_keyboard_off('\uf403'), mdi_keyboard_return('\uf404'), mdi_keyboard_tab(
        '\uf405'
    ),
    mdi_keyboard_variant('\uf406'), mdi_label('\uf407'), mdi_label_outline('\uf408'), mdi_lan(
        '\uf409'
    ),
    mdi_lan_connect('\uf40a'), mdi_lan_disconnect('\uf40b'), mdi_lan_pending('\uf40c'), mdi_language_csharp(
        '\uf40d'
    ),
    mdi_language_css3('\uf40e'), mdi_language_html5('\uf40f'), mdi_language_javascript('\uf410'), mdi_language_php(
        '\uf411'
    ),
    mdi_language_python('\uf412'), mdi_language_python_text('\uf413'), mdi_laptop('\uf414'), mdi_laptop_chromebook(
        '\uf415'
    ),
    mdi_laptop_mac('\uf416'), mdi_laptop_windows('\uf417'), mdi_lastfm('\uf418'), mdi_launch(
        '\uf419'
    ),
    mdi_layers('\uf41a'), mdi_layers_off('\uf41b'), mdi_leaf('\uf41c'), mdi_led_off('\uf41d'), mdi_led_on(
        '\uf41e'
    ),
    mdi_led_outline('\uf41f'), mdi_led_variant_off('\uf420'), mdi_led_variant_on('\uf421'), mdi_led_variant_outline(
        '\uf422'
    ),
    mdi_library('\uf423'), mdi_library_books('\uf424'), mdi_library_music('\uf425'), mdi_library_plus(
        '\uf426'
    ),
    mdi_lightbulb('\uf427'), mdi_lightbulb_outline('\uf428'), mdi_link('\uf429'), mdi_link_off(
        '\uf42a'
    ),
    mdi_link_variant('\uf42b'), mdi_link_variant_off('\uf42c'), mdi_linkedin('\uf42d'), mdi_linkedin_box(
        '\uf42e'
    ),
    mdi_linux('\uf42f'), mdi_lock('\uf430'), mdi_lock_open('\uf431'), mdi_lock_open_outline('\uf432'), mdi_lock_outline(
        '\uf433'
    ),
    mdi_login('\uf434'), mdi_logout('\uf435'), mdi_looks('\uf436'), mdi_loupe('\uf437'), mdi_lumx(
        '\uf438'
    ),
    mdi_magnet('\uf439'), mdi_magnet_on('\uf43a'), mdi_magnify('\uf43b'), mdi_magnify_minus('\uf43c'), mdi_magnify_plus(
        '\uf43d'
    ),
    mdi_mail_ru('\uf43e'), mdi_map('\uf43f'), mdi_map_marker('\uf440'), mdi_map_marker_circle(
        '\uf441'
    ),
    mdi_map_marker_multiple('\uf442'), mdi_map_marker_off('\uf443'), mdi_map_marker_radius('\uf444'), mdi_margin(
        '\uf445'
    ),
    mdi_markdown('\uf446'), mdi_marker_check('\uf447'), mdi_martini('\uf448'), mdi_material_ui(
        '\uf449'
    ),
    mdi_math_compass('\uf44a'), mdi_maxcdn('\uf44b'), mdi_medium('\uf44c'), mdi_memory('\uf44d'), mdi_menu(
        '\uf44e'
    ),
    mdi_menu_down('\uf44f'), mdi_menu_left('\uf450'), mdi_menu_right('\uf451'), mdi_menu_up('\uf452'), mdi_message(
        '\uf453'
    ),
    mdi_message_alert('\uf454'), mdi_message_draw('\uf455'), mdi_message_image('\uf456'), mdi_message_outline(
        '\uf457'
    ),
    mdi_message_processing('\uf458'), mdi_message_reply('\uf459'), mdi_message_reply_text('\uf45a'), mdi_message_text(
        '\uf45b'
    ),
    mdi_message_text_outline('\uf45c'), mdi_message_video('\uf45d'), mdi_microphone('\uf45e'), mdi_microphone_off(
        '\uf45f'
    ),
    mdi_microphone_outline('\uf460'), mdi_microphone_settings('\uf461'), mdi_microphone_variant(
        '\uf462'
    ),
    mdi_microphone_variant_off('\uf463'), mdi_microsoft('\uf464'), mdi_minus('\uf465'), mdi_minus_box(
        '\uf466'
    ),
    mdi_minus_circle('\uf467'), mdi_minus_circle_outline('\uf468'), mdi_minus_network('\uf469'), mdi_monitor(
        '\uf46a'
    ),
    mdi_monitor_multiple('\uf46b'), mdi_more('\uf46c'), mdi_motorbike('\uf46d'), mdi_mouse('\uf46e'), mdi_mouse_off(
        '\uf46f'
    ),
    mdi_mouse_variant('\uf470'), mdi_mouse_variant_off('\uf471'), mdi_movie('\uf472'), mdi_multiplication(
        '\uf473'
    ),
    mdi_multiplication_box('\uf474'), mdi_music_box('\uf475'), mdi_music_box_outline('\uf476'), mdi_music_circle(
        '\uf477'
    ),
    mdi_music_note('\uf478'), mdi_music_note_eighth('\uf479'), mdi_music_note_half('\uf47a'), mdi_music_note_off(
        '\uf47b'
    ),
    mdi_music_note_quarter('\uf47c'), mdi_music_note_sixteenth('\uf47d'), mdi_music_note_whole(
        '\uf47e'
    ),
    mdi_nature('\uf47f'), mdi_nature_people('\uf480'), mdi_navigation('\uf481'), mdi_needle('\uf482'), mdi_nest_protect(
        '\uf483'
    ),
    mdi_nest_thermostat('\uf484'), mdi_newspaper('\uf485'), mdi_nfc('\uf486'), mdi_nfc_tap('\uf487'), mdi_nfc_variant(
        '\uf488'
    ),
    mdi_nodejs('\uf489'), mdi_note('\uf48a'), mdi_note_outline('\uf48b'), mdi_note_plus('\uf48c'), mdi_note_plus_outline(
        '\uf48d'
    ),
    mdi_note_text('\uf48e'), mdi_notification_clear_all('\uf48f'), mdi_numeric('\uf490'), mdi_numeric_0_box(
        '\uf491'
    ),
    mdi_numeric_0_box_multiple_outline('\uf492'), mdi_numeric_0_box_outline('\uf493'), mdi_numeric_1_box(
        '\uf494'
    ),
    mdi_numeric_1_box_multiple_outline('\uf495'), mdi_numeric_1_box_outline('\uf496'), mdi_numeric_2_box(
        '\uf497'
    ),
    mdi_numeric_2_box_multiple_outline('\uf498'), mdi_numeric_2_box_outline('\uf499'), mdi_numeric_3_box(
        '\uf49a'
    ),
    mdi_numeric_3_box_multiple_outline('\uf49b'), mdi_numeric_3_box_outline('\uf49c'), mdi_numeric_4_box(
        '\uf49d'
    ),
    mdi_numeric_4_box_multiple_outline('\uf49e'), mdi_numeric_4_box_outline('\uf49f'), mdi_numeric_5_box(
        '\uf4a0'
    ),
    mdi_numeric_5_box_multiple_outline('\uf4a1'), mdi_numeric_5_box_outline('\uf4a2'), mdi_numeric_6_box(
        '\uf4a3'
    ),
    mdi_numeric_6_box_multiple_outline('\uf4a4'), mdi_numeric_6_box_outline('\uf4a5'), mdi_numeric_7_box(
        '\uf4a6'
    ),
    mdi_numeric_7_box_multiple_outline('\uf4a7'), mdi_numeric_7_box_outline('\uf4a8'), mdi_numeric_8_box(
        '\uf4a9'
    ),
    mdi_numeric_8_box_multiple_outline('\uf4aa'), mdi_numeric_8_box_outline('\uf4ab'), mdi_numeric_9_box(
        '\uf4ac'
    ),
    mdi_numeric_9_box_multiple_outline('\uf4ad'), mdi_numeric_9_box_outline('\uf4ae'), mdi_numeric_9_plus_box(
        '\uf4af'
    ),
    mdi_numeric_9_plus_box_multiple_outline('\uf4b0'), mdi_numeric_9_plus_box_outline('\uf4b1'), mdi_nutrition(
        '\uf4b2'
    ),
    mdi_octagon('\uf4b3'), mdi_octagon_outline('\uf4b4'), mdi_odnoklassniki('\uf4b5'), mdi_office(
        '\uf4b6'
    ),
    mdi_oil('\uf4b7'), mdi_oil_temperature('\uf4b8'), mdi_omega('\uf4b9'), mdi_onedrive('\uf4ba'), mdi_open_in_app(
        '\uf4bb'
    ),
    mdi_open_in_new('\uf4bc'), mdi_opera('\uf4bd'), mdi_ornament('\uf4be'), mdi_ornament_variant(
        '\uf4bf'
    ),
    mdi_outbox('\uf4c0'), mdi_owl('\uf4c1'), mdi_package('\uf4c2'), mdi_package_down('\uf4c3'), mdi_package_up(
        '\uf4c4'
    ),
    mdi_package_variant('\uf4c5'), mdi_package_variant_closed('\uf4c6'), mdi_palette('\uf4c7'), mdi_palette_advanced(
        '\uf4c8'
    ),
    mdi_panda('\uf4c9'), mdi_pandora('\uf4ca'), mdi_panorama('\uf4cb'), mdi_panorama_fisheye(
        '\uf4cc'
    ),
    mdi_panorama_horizontal('\uf4cd'), mdi_panorama_vertical('\uf4ce'), mdi_panorama_wide_angle(
        '\uf4cf'
    ),
    mdi_paper_cut_vertical('\uf4d0'), mdi_paperclip('\uf4d1'), mdi_parking('\uf4d2'), mdi_pause(
        '\uf4d3'
    ),
    mdi_pause_circle('\uf4d4'), mdi_pause_circle_outline('\uf4d5'), mdi_pause_octagon('\uf4d6'), mdi_pause_octagon_outline(
        '\uf4d7'
    ),
    mdi_paw('\uf4d8'), mdi_pen('\uf4d9'), mdi_pencil('\uf4da'), mdi_pencil_box('\uf4db'), mdi_pencil_box_outline(
        '\uf4dc'
    ),
    mdi_pencil_lock('\uf4dd'), mdi_pencil_off('\uf4de'), mdi_percent('\uf4df'), mdi_pharmacy(
        '\uf4e0'
    ),
    mdi_phone('\uf4e1'), mdi_phone_bluetooth('\uf4e2'), mdi_phone_forward('\uf4e3'), mdi_phone_hangup(
        '\uf4e4'
    ),
    mdi_phone_in_talk('\uf4e5'), mdi_phone_incoming('\uf4e6'), mdi_phone_locked('\uf4e7'), mdi_phone_log(
        '\uf4e8'
    ),
    mdi_phone_missed('\uf4e9'), mdi_phone_outgoing('\uf4ea'), mdi_phone_paused('\uf4eb'), mdi_phone_settings(
        '\uf4ec'
    ),
    mdi_phone_voip('\uf4ed'), mdi_pi('\uf4ee'), mdi_pi_box('\uf4ef'), mdi_pig('\uf4f0'), mdi_pill(
        '\uf4f1'
    ),
    mdi_pin('\uf4f2'), mdi_pin_off('\uf4f3'), mdi_pine_tree('\uf4f4'), mdi_pine_tree_box('\uf4f5'), mdi_pinterest(
        '\uf4f6'
    ),
    mdi_pinterest_box('\uf4f7'), mdi_pizza('\uf4f8'), mdi_play('\uf4f9'), mdi_play_box_outline(
        '\uf4fa'
    ),
    mdi_play_circle('\uf4fb'), mdi_play_circle_outline('\uf4fc'), mdi_play_pause('\uf4fd'), mdi_play_protected_content(
        '\uf4fe'
    ),
    mdi_playlist_minus('\uf4ff'), mdi_playlist_play('\uf500'), mdi_playlist_plus('\uf501'), mdi_playlist_remove(
        '\uf502'
    ),
    mdi_playstation('\uf503'), mdi_plus('\uf504'), mdi_plus_box('\uf505'), mdi_plus_circle('\uf506'), mdi_plus_circle_multiple_outline(
        '\uf507'
    ),
    mdi_plus_circle_outline('\uf508'), mdi_plus_network('\uf509'), mdi_plus_one('\uf50a'), mdi_pocket(
        '\uf50b'
    ),
    mdi_pokeball('\uf50c'), mdi_polaroid('\uf50d'), mdi_poll('\uf50e'), mdi_poll_box('\uf50f'), mdi_polymer(
        '\uf510'
    ),
    mdi_popcorn('\uf511'), mdi_pound('\uf512'), mdi_pound_box('\uf513'), mdi_power('\uf514'), mdi_power_settings(
        '\uf515'
    ),
    mdi_power_socket('\uf516'), mdi_presentation('\uf517'), mdi_presentation_play('\uf518'), mdi_printer(
        '\uf519'
    ),
    mdi_printer_3d('\uf51a'), mdi_printer_alert('\uf51b'), mdi_professional_hexagon('\uf51c'), mdi_projector(
        '\uf51d'
    ),
    mdi_projector_screen('\uf51e'), mdi_pulse('\uf51f'), mdi_puzzle('\uf520'), mdi_qrcode('\uf521'), mdi_qrcode_scan(
        '\uf522'
    ),
    mdi_quadcopter('\uf523'), mdi_quality_high('\uf524'), mdi_quicktime('\uf525'), mdi_radar(
        '\uf526'
    ),
    mdi_radiator('\uf527'), mdi_radio('\uf528'), mdi_radio_handheld('\uf529'), mdi_radio_tower(
        '\uf52a'
    ),
    mdi_radioactive('\uf52b'), mdi_radiobox_blank('\uf52c'), mdi_radiobox_marked('\uf52d'), mdi_raspberrypi(
        '\uf52e'
    ),
    mdi_ray_end('\uf52f'), mdi_ray_end_arrow('\uf530'), mdi_ray_start('\uf531'), mdi_ray_start_arrow(
        '\uf532'
    ),
    mdi_ray_start_end('\uf533'), mdi_ray_vertex('\uf534'), mdi_rdio('\uf535'), mdi_read('\uf536'), mdi_readability(
        '\uf537'
    ),
    mdi_receipt('\uf538'), mdi_record('\uf539'), mdi_record_rec('\uf53a'), mdi_recycle('\uf53b'), mdi_reddit(
        '\uf53c'
    ),
    mdi_redo('\uf53d'), mdi_redo_variant('\uf53e'), mdi_refresh('\uf53f'), mdi_regex('\uf540'), mdi_relative_scale(
        '\uf541'
    ),
    mdi_reload('\uf542'), mdi_remote('\uf543'), mdi_rename_box('\uf544'), mdi_repeat('\uf545'), mdi_repeat_off(
        '\uf546'
    ),
    mdi_repeat_once('\uf547'), mdi_replay('\uf548'), mdi_reply('\uf549'), mdi_reply_all('\uf54a'), mdi_reproduction(
        '\uf54b'
    ),
    mdi_resize_bottom_right('\uf54c'), mdi_responsive('\uf54d'), mdi_rewind('\uf54e'), mdi_ribbon(
        '\uf54f'
    ),
    mdi_road('\uf550'), mdi_road_variant('\uf551'), mdi_rocket('\uf552'), mdi_rotate_3d('\uf553'), mdi_rotate_left(
        '\uf554'
    ),
    mdi_rotate_left_variant('\uf555'), mdi_rotate_right('\uf556'), mdi_rotate_right_variant('\uf557'), mdi_router_wireless(
        '\uf558'
    ),
    mdi_routes('\uf559'), mdi_rss('\uf55a'), mdi_rss_box('\uf55b'), mdi_ruler('\uf55c'), mdi_run(
        '\uf55d'
    ),
    mdi_sale('\uf55e'), mdi_satellite('\uf55f'), mdi_satellite_variant('\uf560'), mdi_scale('\uf561'), mdi_scale_bathroom(
        '\uf562'
    ),
    mdi_school('\uf563'), mdi_screen_rotation('\uf564'), mdi_screen_rotation_lock('\uf565'), mdi_screwdriver(
        '\uf566'
    ),
    mdi_script('\uf567'), mdi_sd('\uf568'), mdi_seal('\uf569'), mdi_seat_flat('\uf56a'), mdi_seat_flat_angled(
        '\uf56b'
    ),
    mdi_seat_individual_suite('\uf56c'), mdi_seat_legroom_extra('\uf56d'), mdi_seat_legroom_normal(
        '\uf56e'
    ),
    mdi_seat_legroom_reduced('\uf56f'), mdi_seat_recline_extra('\uf570'), mdi_seat_recline_normal(
        '\uf571'
    ),
    mdi_security('\uf572'), mdi_security_network('\uf573'), mdi_select('\uf574'), mdi_select_all(
        '\uf575'
    ),
    mdi_select_inverse('\uf576'), mdi_select_off('\uf577'), mdi_selection('\uf578'), mdi_send(
        '\uf579'
    ),
    mdi_server('\uf57a'), mdi_server_minus('\uf57b'), mdi_server_network('\uf57c'), mdi_server_network_off(
        '\uf57d'
    ),
    mdi_server_off('\uf57e'), mdi_server_plus('\uf57f'), mdi_server_remove('\uf580'), mdi_server_security(
        '\uf581'
    ),
    mdi_settings('\uf582'), mdi_settings_box('\uf583'), mdi_shape_plus('\uf584'), mdi_share('\uf585'), mdi_share_variant(
        '\uf586'
    ),
    mdi_shield('\uf587'), mdi_shield_outline('\uf588'), mdi_shopping('\uf589'), mdi_shopping_music(
        '\uf58a'
    ),
    mdi_shredder('\uf58b'), mdi_shuffle('\uf58c'), mdi_shuffle_disabled('\uf58d'), mdi_shuffle_variant(
        '\uf58e'
    ),
    mdi_sigma('\uf58f'), mdi_sign_caution('\uf590'), mdi_signal('\uf591'), mdi_silverware('\uf592'), mdi_silverware_fork(
        '\uf593'
    ),
    mdi_silverware_spoon('\uf594'), mdi_silverware_variant('\uf595'), mdi_sim('\uf596'), mdi_sim_alert(
        '\uf597'
    ),
    mdi_sim_off('\uf598'), mdi_sitemap('\uf599'), mdi_skip_backward('\uf59a'), mdi_skip_forward(
        '\uf59b'
    ),
    mdi_skip_next('\uf59c'), mdi_skip_previous('\uf59d'), mdi_skype('\uf59e'), mdi_skype_business(
        '\uf59f'
    ),
    mdi_slack('\uf5a0'), mdi_sleep('\uf5a1'), mdi_sleep_off('\uf5a2'), mdi_smoking('\uf5a3'), mdi_smoking_off(
        '\uf5a4'
    ),
    mdi_snapchat('\uf5a5'), mdi_snowman('\uf5a6'), mdi_sofa('\uf5a7'), mdi_sort('\uf5a8'), mdi_sort_alphabetical(
        '\uf5a9'
    ),
    mdi_sort_ascending('\uf5aa'), mdi_sort_descending('\uf5ab'), mdi_sort_numeric('\uf5ac'), mdi_sort_variant(
        '\uf5ad'
    ),
    mdi_soundcloud('\uf5ae'), mdi_source_fork('\uf5af'), mdi_source_pull('\uf5b0'), mdi_speaker(
        '\uf5b1'
    ),
    mdi_speaker_off('\uf5b2'), mdi_speedometer('\uf5b3'), mdi_spellcheck('\uf5b4'), mdi_spotify(
        '\uf5b5'
    ),
    mdi_spotlight('\uf5b6'), mdi_spotlight_beam('\uf5b7'), mdi_square_inc('\uf5b8'), mdi_square_inc_cash(
        '\uf5b9'
    ),
    mdi_stackoverflow('\uf5ba'), mdi_stairs('\uf5bb'), mdi_star('\uf5bc'), mdi_star_circle('\uf5bd'), mdi_star_half(
        '\uf5be'
    ),
    mdi_star_off('\uf5bf'), mdi_star_outline('\uf5c0'), mdi_steam('\uf5c1'), mdi_steering('\uf5c2'), mdi_step_backward(
        '\uf5c3'
    ),
    mdi_step_backward_2('\uf5c4'), mdi_step_forward('\uf5c5'), mdi_step_forward_2('\uf5c6'), mdi_stethoscope(
        '\uf5c7'
    ),
    mdi_stocking('\uf5c8'), mdi_stop('\uf5c9'), mdi_store('\uf5ca'), mdi_store_24_hour('\uf5cb'), mdi_stove(
        '\uf5cc'
    ),
    mdi_subway('\uf5cd'), mdi_sunglasses('\uf5ce'), mdi_swap_horizontal('\uf5cf'), mdi_swap_vertical(
        '\uf5d0'
    ),
    mdi_swim('\uf5d1'), mdi_switch('\uf5d2'), mdi_sword('\uf5d3'), mdi_sync('\uf5d4'), mdi_sync_alert(
        '\uf5d5'
    ),
    mdi_sync_off('\uf5d6'), mdi_tab('\uf5d7'), mdi_tab_unselected('\uf5d8'), mdi_table('\uf5d9'), mdi_table_column_plus_after(
        '\uf5da'
    ),
    mdi_table_column_plus_before('\uf5db'), mdi_table_column_remove('\uf5dc'), mdi_table_column_width(
        '\uf5dd'
    ),
    mdi_table_edit('\uf5de'), mdi_table_large('\uf5df'), mdi_table_row_height('\uf5e0'), mdi_table_row_plus_after(
        '\uf5e1'
    ),
    mdi_table_row_plus_before('\uf5e2'), mdi_table_row_remove('\uf5e3'), mdi_tablet('\uf5e4'), mdi_tablet_android(
        '\uf5e5'
    ),
    mdi_tablet_ipad('\uf5e6'), mdi_tag('\uf5e7'), mdi_tag_faces('\uf5e8'), mdi_tag_multiple('\uf5e9'), mdi_tag_outline(
        '\uf5ea'
    ),
    mdi_tag_text_outline('\uf5eb'), mdi_target('\uf5ec'), mdi_taxi('\uf5ed'), mdi_teamviewer(
        '\uf5ee'
    ),
    mdi_telegram('\uf5ef'), mdi_television('\uf5f0'), mdi_television_guide('\uf5f1'), mdi_temperature_celsius(
        '\uf5f2'
    ),
    mdi_temperature_fahrenheit('\uf5f3'), mdi_temperature_kelvin('\uf5f4'), mdi_tennis('\uf5f5'), mdi_tent(
        '\uf5f6'
    ),
    mdi_terrain('\uf5f7'), mdi_text_to_speech('\uf5f8'), mdi_text_to_speech_off('\uf5f9'), mdi_texture(
        '\uf5fa'
    ),
    mdi_theater('\uf5fb'), mdi_theme_light_dark('\uf5fc'), mdi_thermometer('\uf5fd'), mdi_thermometer_lines(
        '\uf5fe'
    ),
    mdi_thumb_down('\uf5ff'), mdi_thumb_down_outline('\uf600'), mdi_thumb_up('\uf601'), mdi_thumb_up_outline(
        '\uf602'
    ),
    mdi_thumbs_up_down('\uf603'), mdi_ticket('\uf604'), mdi_ticket_account('\uf605'), mdi_ticket_confirmation(
        '\uf606'
    ),
    mdi_tie('\uf607'), mdi_timelapse('\uf608'), mdi_timer('\uf609'), mdi_timer_10('\uf60a'), mdi_timer_3(
        '\uf60b'
    ),
    mdi_timer_off('\uf60c'), mdi_timer_sand('\uf60d'), mdi_timetable('\uf60e'), mdi_toggle_switch(
        '\uf60f'
    ),
    mdi_toggle_switch_off('\uf610'), mdi_tooltip('\uf611'), mdi_tooltip_edit('\uf612'), mdi_tooltip_image(
        '\uf613'
    ),
    mdi_tooltip_outline('\uf614'), mdi_tooltip_outline_plus('\uf615'), mdi_tooltip_text('\uf616'), mdi_tor(
        '\uf617'
    ),
    mdi_traffic_light('\uf618'), mdi_train('\uf619'), mdi_tram('\uf61a'), mdi_transcribe('\uf61b'), mdi_transcribe_close(
        '\uf61c'
    ),
    mdi_transfer('\uf61d'), mdi_tree('\uf61e'), mdi_trello('\uf61f'), mdi_trending_down('\uf620'), mdi_trending_neutral(
        '\uf621'
    ),
    mdi_trending_up('\uf622'), mdi_triangle('\uf623'), mdi_triangle_outline('\uf624'), mdi_trophy(
        '\uf625'
    ),
    mdi_trophy_award('\uf626'), mdi_trophy_outline('\uf627'), mdi_trophy_variant('\uf628'), mdi_trophy_variant_outline(
        '\uf629'
    ),
    mdi_truck('\uf62a'), mdi_truck_delivery('\uf62b'), mdi_tshirt_crew('\uf62c'), mdi_tshirt_v(
        '\uf62d'
    ),
    mdi_tumblr('\uf62e'), mdi_tumblr_reblog('\uf62f'), mdi_twitch('\uf630'), mdi_twitter('\uf631'), mdi_twitter_box(
        '\uf632'
    ),
    mdi_twitter_circle('\uf633'), mdi_twitter_retweet('\uf634'), mdi_ubuntu('\uf635'), mdi_umbraco(
        '\uf636'
    ),
    mdi_umbrella('\uf637'), mdi_umbrella_outline('\uf638'), mdi_undo('\uf639'), mdi_undo_variant(
        '\uf63a'
    ),
    mdi_unfold_less('\uf63b'), mdi_unfold_more('\uf63c'), mdi_ungroup('\uf63d'), mdi_untappd(
        '\uf63e'
    ),
    mdi_upload('\uf63f'), mdi_usb('\uf640'), mdi_vector_arrange_above('\uf641'), mdi_vector_arrange_below(
        '\uf642'
    ),
    mdi_vector_circle('\uf643'), mdi_vector_circle_variant('\uf644'), mdi_vector_combine('\uf645'), mdi_vector_curve(
        '\uf646'
    ),
    mdi_vector_difference('\uf647'), mdi_vector_difference_ab('\uf648'), mdi_vector_difference_ba(
        '\uf649'
    ),
    mdi_vector_intersection('\uf64a'), mdi_vector_line('\uf64b'), mdi_vector_point('\uf64c'), mdi_vector_polygon(
        '\uf64d'
    ),
    mdi_vector_polyline('\uf64e'), mdi_vector_selection('\uf64f'), mdi_vector_square('\uf650'), mdi_vector_triangle(
        '\uf651'
    ),
    mdi_vector_union('\uf652'), mdi_verified('\uf653'), mdi_vibrate('\uf654'), mdi_video('\uf655'), mdi_video_off(
        '\uf656'
    ),
    mdi_video_switch('\uf657'), mdi_view_agenda('\uf658'), mdi_view_array('\uf659'), mdi_view_carousel(
        '\uf65a'
    ),
    mdi_view_column('\uf65b'), mdi_view_dashboard('\uf65c'), mdi_view_day('\uf65d'), mdi_view_grid(
        '\uf65e'
    ),
    mdi_view_headline('\uf65f'), mdi_view_list('\uf660'), mdi_view_module('\uf661'), mdi_view_quilt(
        '\uf662'
    ),
    mdi_view_stream('\uf663'), mdi_view_week('\uf664'), mdi_vimeo('\uf665'), mdi_vine('\uf666'), mdi_vk(
        '\uf667'
    ),
    mdi_vk_box('\uf668'), mdi_vk_circle('\uf669'), mdi_voicemail('\uf66a'), mdi_volume_high('\uf66b'), mdi_volume_low(
        '\uf66c'
    ),
    mdi_volume_medium('\uf66d'), mdi_volume_off('\uf66e'), mdi_vpn('\uf66f'), mdi_walk('\uf670'), mdi_wallet(
        '\uf671'
    ),
    mdi_wallet_giftcard('\uf672'), mdi_wallet_membership('\uf673'), mdi_wallet_travel('\uf674'), mdi_wan(
        '\uf675'
    ),
    mdi_watch('\uf676'), mdi_watch_export('\uf677'), mdi_watch_import('\uf678'), mdi_water('\uf679'), mdi_water_off(
        '\uf67a'
    ),
    mdi_water_percent('\uf67b'), mdi_water_pump('\uf67c'), mdi_weather_cloudy('\uf67d'), mdi_weather_fog(
        '\uf67e'
    ),
    mdi_weather_hail('\uf67f'), mdi_weather_lightning('\uf680'), mdi_weather_night('\uf681'), mdi_weather_partlycloudy(
        '\uf682'
    ),
    mdi_weather_pouring('\uf683'), mdi_weather_rainy('\uf684'), mdi_weather_snowy('\uf685'), mdi_weather_sunny(
        '\uf686'
    ),
    mdi_weather_sunset('\uf687'), mdi_weather_sunset_down('\uf688'), mdi_weather_sunset_up('\uf689'), mdi_weather_windy(
        '\uf68a'
    ),
    mdi_weather_windy_variant('\uf68b'), mdi_web('\uf68c'), mdi_webcam('\uf68d'), mdi_weight(
        '\uf68e'
    ),
    mdi_weight_kilogram('\uf68f'), mdi_whatsapp('\uf690'), mdi_wheelchair_accessibility('\uf691'), mdi_white_balance_auto(
        '\uf692'
    ),
    mdi_white_balance_incandescent('\uf693'), mdi_white_balance_irradescent('\uf694'), mdi_white_balance_sunny(
        '\uf695'
    ),
    mdi_wifi('\uf696'), mdi_wifi_off('\uf697'), mdi_wii('\uf698'), mdi_wikipedia('\uf699'), mdi_window_close(
        '\uf69a'
    ),
    mdi_window_closed('\uf69b'), mdi_window_maximize('\uf69c'), mdi_window_minimize('\uf69d'), mdi_window_open(
        '\uf69e'
    ),
    mdi_window_restore('\uf69f'), mdi_windows('\uf6a0'), mdi_wordpress('\uf6a1'), mdi_worker(
        '\uf6a2'
    ),
    mdi_wrap('\uf6a3'), mdi_wrench('\uf6a4'), mdi_wunderlist('\uf6a5'), mdi_xbox('\uf6a6'), mdi_xbox_controller(
        '\uf6a7'
    ),
    mdi_xbox_controller_off('\uf6a8'), mdi_xda('\uf6a9'), mdi_xing('\uf6aa'), mdi_xing_box('\uf6ab'), mdi_xing_circle(
        '\uf6ac'
    ),
    mdi_xml('\uf6ad'), mdi_yeast('\uf6ae'), mdi_yelp('\uf6af'), mdi_youtube_play('\uf6b0'), mdi_zip_box(
        '\uf6b1'
    );

    override fun key(): String {
        return name.replace('_', '-')
    }

    override fun character(): Char {
        return character
    }
}